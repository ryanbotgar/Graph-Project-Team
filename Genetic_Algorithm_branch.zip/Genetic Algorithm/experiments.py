"""Experiment campaign for the genetic algorithm.

One CSV row per run. Three groups of runs:
  extrinsic : default GA, the problem changes (size, layout, time windows)
  intrinsic : one 1,000-customer instance, one GA parameter changes at a time
  ags       : Belgian CVRP benchmarks with a best-known solution (gap)

Usage: python experiments.py instances_folder ags_folder results.csv
"""
import csv
import json
import os
import sys
import time
from multiprocessing import Pool

import ga_cvrptw as ga

AGS_BKS = {"Leuven1": 192848, "Antwerp1": 477256, "Ghent1": 469481, "Ghent2": 257631}


def budget(n):
    """CPU seconds given to one run, by instance size."""
    return 60 if n <= 1000 else (300 if n <= 5000 else 600)


def run_one(job):
    inst = ga.load_instance(job["path"])
    params = job["params"]
    limit = job.get("time") or budget(inst["n"])
    t0 = time.process_time()
    routes, dist, history = ga.solve(inst, time_limit=limit, seed=job["seed"], **params)
    cpu = time.process_time() - t0
    ok, _, msg = ga.check_solution(routes, inst)
    meta = inst.get("meta", {})
    name = os.path.splitext(os.path.basename(job["path"]))[0]
    bks = AGS_BKS.get(name)
    return {
        "group": job["group"], "instance": name, "customers": inst["n"],
        "layout": meta.get("layout", ""), "tw": meta.get("tw", ""),
        "varied": job.get("varied", ""), "value": job.get("value", ""),
        "pop_size": params.get("pop_size", "auto"), "p_mutation": params.get("p_mutation", 0.2),
        "n_neighbors": params.get("n_neighbors", 20), "seed": job["seed"],
        "time_limit": limit, "cpu_seconds": round(cpu, 1),
        "first_cost": round(history[0][1], 2), "cost": round(dist, 2),
        "improvement_%": round(100 * (history[0][1] - dist) / history[0][1], 2),
        "trucks": len(routes), "feasible": ok, "message": msg,
        "bks": bks or "", "gap_%": round(ga.gap(dist, bks), 2) if bks else "",
        "history": json.dumps([(round(t, 1), round(d, 1)) for t, d, _ in history]),
    }


def make_jobs(inst_dir, ags_dir):
    jobs = []
    files = sorted(os.listdir(inst_dir))

    def size(f):
        return int(f.split("_n")[1].split("_")[0])

    # extrinsic: every generated instance, default parameters
    for f in files:
        seeds = [1, 2, 3] if size(f) <= 1000 else [1]
        for s in seeds:
            jobs.append({"group": "extrinsic", "path": os.path.join(inst_dir, f), "seed": s, "params": {}})

    # intrinsic: one factor at a time on one 1,000-customer instance
    base = os.path.join(inst_dir, "synthetic_random_wide_n1000_s1.npz")
    grid = {"pop_size": [10, 50], "p_mutation": [0.0, 0.5], "n_neighbors": [5, 10, 40]}
    for name, values in grid.items():
        for v in values:
            for s in [1, 2, 3]:
                jobs.append({"group": "intrinsic", "path": base, "seed": s, "params": {name: v},
                             "varied": name, "value": v})

    # benchmarks with a best-known solution
    for name, t in [("Leuven1", 300), ("Antwerp1", 300), ("Ghent1", 600), ("Ghent2", 600)]:
        jobs.append({"group": "ags", "path": os.path.join(ags_dir, name + ".vrp"), "seed": 1,
                     "params": {}, "time": t})

    # short runs first, so results arrive early
    jobs.sort(key=lambda j: (j.get("time") or budget(size(j["path"]) if "_n" in j["path"] else 99999)))
    return jobs


if __name__ == "__main__":
    inst_dir, ags_dir, out = sys.argv[1:4]
    jobs = make_jobs(inst_dir, ags_dir)
    print(len(jobs), "runs", flush=True)
    with open(out, "w", newline="") as f, Pool(2) as pool:
        writer = None
        for k, row in enumerate(pool.imap_unordered(run_one, jobs), 1):
            if writer is None:
                writer = csv.DictWriter(f, fieldnames=list(row))
                writer.writeheader()
            writer.writerow(row)
            f.flush()
            print(k, "/", len(jobs), row["group"], row["instance"], row["varied"], row["value"],
                  "seed", row["seed"], "cost", row["cost"], "trucks", row["trucks"],
                  "feasible", row["feasible"], row["gap_%"], flush=True)
