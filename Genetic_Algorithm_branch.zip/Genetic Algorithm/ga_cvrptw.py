"""
Memetic genetic algorithm for the CVRP and the CVRPTW.

How it works (one generation = one child):
  1. Parental selection   : two binary tournaments pick two parents.
  2. Crossover (OX)       : the child copies a slice of parent 1's order,
                            then fills the rest in parent 2's order.
  3. Mutation             : with a small probability, swap or reverse part of the order.
  4. Decoding (Split)     : the child's order of customers ("giant tour") is cut
                            into routes in the best possible way, respecting the
                            truck capacity and the time windows.
  5. Education (local search): relocate, swap, 2-opt* and 2-opt moves improve
                            the child's routes (this is what makes it "memetic").
  6. Replacement          : the child joins the population; when it is too big,
                            clones and then the worst individuals are removed.

A chromosome is a permutation of the customers 1..n (the depot 0 is never in it).
A solution is a list of routes, each a list of customers without the depot.

Usage:
    python ga_cvrptw.py path/to/C101.vrp --time 60 --seed 1 --sol path/to/C101.sol
"""

import argparse
import math
import random
import time
from array import array

import numpy as np
import vrplib

EPS = 1e-9
BIG = 3000  # above this many customers: compact storage, faster construction, smaller population


# --------------------------------------------------------------------------
# Compact distance storage
# --------------------------------------------------------------------------
# The distance table is a list of rows; each row is a Python array of numbers.
# Small instances use 8-byte numbers ('d', exact). Big ones use 4-byte numbers
# ('f'): a 10,000-customer table then takes 400 MB instead of about 3 GB as a
# list of lists, and D[i][j] stays a fast lookup.
def _round(d, rounding):
    if rounding == "dimacs":
        return np.floor(d * 10.0 + 1e-6) / 10.0
    if rounding == "round":
        return np.floor(d + 0.5)
    return d


def _typecode(n_nodes):
    return "f" if n_nodes - 1 > BIG else "d"


def _rows_from_matrix(M, rounding="none"):
    M = np.asarray(M)
    code = _typecode(M.shape[0])
    dtype = np.float32 if code == "f" else np.float64
    rows = []
    for i in range(M.shape[0]):
        r = array(code)
        r.frombytes(np.ascontiguousarray(_round(M[i].astype(float), rounding), dtype=dtype).tobytes())
        rows.append(r)
    return rows


def _rows_from_coords(X, Y, rounding):
    """Euclidean distances computed one row at a time (never the full table at once)."""
    X, Y = np.asarray(X, dtype=float), np.asarray(Y, dtype=float)
    code = _typecode(len(X))
    dtype = np.float32 if code == "f" else np.float64
    rows = []
    for i in range(len(X)):
        r = array(code)
        r.frombytes(_round(np.hypot(X - X[i], Y - Y[i]), rounding).astype(dtype).tobytes())
        rows.append(r)
    return rows


# --------------------------------------------------------------------------
# Instance loading
# --------------------------------------------------------------------------
def load_instance(path, rounding="auto"):
    """Read an instance and return a plain dict the solver uses.

    Accepts both file formats: Solomon .txt files (as downloaded from the
    NEO website) and VRPLIB .vrp files. The format is detected from the file.

    rounding: "dimacs" truncates distances to one decimal (VRPTW benchmark
    convention), "round" rounds to the nearest integer (CVRP benchmark
    convention), "none" keeps exact distances, "auto" picks by problem type.
    """
    if str(path).endswith(".npz"):  # made by instance_generator.py
        return _read_generated(path)
    with open(path) as f:
        head = f.read(2000).upper()
    if not any(ch.isalpha() for ch in head):  # only numbers: Cordeau format
        return _read_cordeau(path, "none" if rounding == "auto" else rounding)
    fmt = "solomon" if ("CUST NO" in head or "VEHICLE" in head and "NODE_COORD" not in head) else "vrplib"
    # compute_edge_weights=False: vrplib would build the full table in 8-byte
    # numbers (800 MB at 10,000 customers); we build compact rows ourselves.
    raw = vrplib.read_instance(path, instance_format=fmt, compute_edge_weights=False)
    n_nodes = len(raw["demand"])  # depot + customers (works for both formats)
    has_tw = "time_window" in raw
    if rounding == "auto":
        rounding = "dimacs" if has_tw else "round"
    if "edge_weight" in raw:  # explicit table in the file: use it as given
        D = _rows_from_matrix(raw["edge_weight"])
    else:
        xy = np.asarray(raw["node_coord"], dtype=float)
        D = _rows_from_coords(xy[:, 0], xy[:, 1], rounding)

    demand = np.asarray(raw["demand"], dtype=float)
    if has_tw:
        tw = np.asarray(raw["time_window"], dtype=float)
        ready, due = tw[:, 0].copy(), tw[:, 1].copy()
    else:  # plain CVRP: windows that never bind
        ready, due = np.zeros(n_nodes), np.full(n_nodes, np.inf)

    service = np.asarray(raw.get("service_time", 0), dtype=float).ravel()
    if service.size == 1:  # one value for every customer
        service = np.full(n_nodes, service[0])
    service[0] = 0.0  # no service at the depot

    return {
        "name": raw.get("name", str(path)),
        "n": n_nodes - 1,  # number of customers
        "Q": float(raw["capacity"]),
        "vehicles": int(raw["vehicles"]) if "vehicles" in raw else None,
        "D": D,
        "q": demand.tolist(),
        "a": ready.tolist(),
        "b": due.tolist(),
        "s": service.tolist(),
        "has_tw": has_tw,
    }


def _read_generated(path):
    """Instances from instance_generator.py: road travel times (possibly
    asymmetric because of one-way streets), demands, windows, service times.
    The cost to minimize is the total travel time."""
    import json
    import os
    z = np.load(path, allow_pickle=False)
    T = z["T"]
    meta = json.loads(str(z["meta"]))
    return {
        "name": meta.get("name", os.path.basename(path)), "n": T.shape[0] - 1,
        "Q": float(z["Q"]), "vehicles": int(z["vehicles"]), "D": _rows_from_matrix(T),
        "q": z["demand"].astype(float).tolist(), "a": z["a"].astype(float).tolist(),
        "b": z["b"].astype(float).tolist(), "s": z["s"].astype(float).tolist(),
        "has_tw": True, "meta": meta,
    }


def _read_cordeau(path, rounding):
    """Cordeau's VRPTW format (the files in C-vrptw.zip).

    Line 1: type, m (number of trucks), n (customers), t (depots)
    Line 2: D (max route duration, 0 = none), Q (truck capacity)
    Then one line per node: i, x, y, service time, demand, f, a,
    a visit-combination numbers, ready time, due time.
    Read token by token, so line breaks do not matter.
    """
    import os
    tok = open(path).read().split()
    _, m, n, t = (int(float(v)) for v in tok[:4])
    pos = 4
    _, Q = float(tok[pos]), float(tok[pos + 1])
    pos += 2 * t
    xs, ys, s, q, a, b = [], [], [], [], [], []
    for _ in range(n + 1):
        x, y, d, dem, f, ncomb = tok[pos + 1:pos + 7]
        pos += 7 + int(float(ncomb))
        e, l = tok[pos], tok[pos + 1]
        pos += 2
        xs.append(float(x)); ys.append(float(y)); s.append(float(d))
        q.append(float(dem)); a.append(float(e)); b.append(float(l))
    s[0] = 0.0
    return {
        "name": os.path.basename(path), "n": n, "Q": Q, "vehicles": m,
        "D": _rows_from_coords(xs, ys, rounding), "q": q, "a": a, "b": b, "s": s, "has_tw": True,
    }


# --------------------------------------------------------------------------
# Route evaluation and an independent checker
# --------------------------------------------------------------------------
def route_eval(route, inst):
    """Return (feasible, distance, load) of one route depot -> route -> depot.

    Service at customer c starts at max(arrival, a[c]): the truck may wait.
    The route is infeasible if any service starts after b[c], if the truck
    gets back to the depot after b[0], or if the load exceeds Q.
    """
    D, q, a, b, s = inst["D"], inst["q"], inst["a"], inst["b"], inst["s"]
    load, dist, t, prev = 0.0, 0.0, a[0], 0
    for c in route:
        load += q[c]
        dist += D[prev][c]
        t = max(a[c], t + s[prev] + D[prev][c])
        if t > b[c] + EPS:
            return False, dist, load
        prev = c
    dist += D[prev][0]
    back = t + s[prev] + D[prev][0]
    feasible = load <= inst["Q"] + EPS and back <= b[0] + EPS
    return feasible, dist, load


def check_solution(routes, inst):
    """Independent check: every customer exactly once, every route feasible,
    and no more trucks than allowed. Returns (ok, total distance, message)."""
    seen = [c for r in routes for c in r]
    if sorted(seen) != list(range(1, inst["n"] + 1)):
        return False, math.inf, "customers missing or visited twice"
    k = inst.get("vehicles")
    if k is not None and len(routes) > k:
        return False, total_distance(routes, inst), f"{len(routes)} trucks used, only {k} allowed"
    total = 0.0
    for k, r in enumerate(routes):
        feasible, dist, load = route_eval(r, inst)
        if not feasible:
            return False, math.inf, f"route {k} breaks capacity or a time window"
        total += dist
    return True, total, "ok"


def total_distance(routes, inst):
    return sum(route_eval(r, inst)[1] for r in routes)


# --------------------------------------------------------------------------
# Split: cut a giant tour into the best set of feasible routes (Prins, 2004)
# --------------------------------------------------------------------------
def split(tour, inst, k=None):
    """Cut the tour into routes: a shortest path in the graph whose arc (i, j)
    is the route serving tour[i:j]. Arcs exist only for feasible routes, so
    every route is feasible.

    With a truck limit k, the path is computed layer by layer (layer r = paths
    using exactly r routes), and the shortest one with at most k routes wins.
    If this tour cannot fit in k routes, it returns the cut with the fewest
    routes (the excess is then penalized and the GA works to remove it)."""
    D, q, a, b, s, Q = inst["D"], inst["q"], inst["a"], inst["b"], inst["s"], inst["Q"]
    n = len(tour)

    # All feasible routes tour[i:j] as arcs (i, j, distance)
    arcs = []
    for i in range(n):
        load, dist, t, prev = 0.0, 0.0, a[0], 0
        for j in range(i, n):
            c = tour[j]
            load += q[c]
            if load > Q + EPS:
                break
            dist += D[prev][c]
            t = max(a[c], t + s[prev] + D[prev][c])
            if t > b[c] + EPS:
                break  # later customers can only be served later still
            prev = c
            if t + s[c] + D[c][0] > b[0] + EPS:
                continue  # cannot close the route here, try a longer one
            arcs.append((i, j + 1, dist + D[c][0]))

    # Unlimited fleet first: one Bellman pass in tour order (arcs are sorted by
    # i, so best[i] is final when its arcs are used). If this uses at most k
    # routes it is also the best cut under the limit, so we can stop here.
    best, pred = [math.inf] * (n + 1), [-1] * (n + 1)
    best[0] = 0.0
    for i, j, c in arcs:
        if best[i] + c < best[j] - EPS:
            best[j], pred[j] = best[i] + c, i
    if best[n] == math.inf:
        return None
    cuts, j = [], n
    while j > 0:
        cuts.append((pred[j], j))
        j = pred[j]
    if k is None or len(cuts) <= k:
        return [list(tour[i:j]) for i, j in reversed(cuts)]

    # Limited fleet: layer r holds the best cost to serve tour[:j] with r routes
    layers = [[0.0] + [math.inf] * n]
    preds = [[-1] * (n + 1)]
    best_r = None
    for r in range(1, n + 1):
        prev_layer, cur, pred = layers[-1], [math.inf] * (n + 1), [-1] * (n + 1)
        for i, j, c in arcs:
            if prev_layer[i] + c < cur[j] - EPS:
                cur[j], pred[j] = prev_layer[i] + c, i
        layers.append(cur)
        preds.append(pred)
        if cur[n] < math.inf and (best_r is None or cur[n] < layers[best_r][n] - EPS):
            if r <= k or best_r is None:
                best_r = r
        if r >= k and best_r is not None:
            break
    if best_r is None:
        return None
    cuts, j = [], n
    for r in range(best_r, 0, -1):
        i = preds[r][j]
        cuts.append((i, j))
        j = i
    return [list(tour[i:j]) for i, j in reversed(cuts)]


def eliminate_routes(routes, inst, k):
    """While there are more than k routes, try to empty one: move each of its
    customers to the cheapest feasible position in the other routes. The
    smallest routes are tried first. Distance may grow; the truck count drops."""
    D = inst["D"]
    routes = [list(r) for r in routes]
    while len(routes) > k:
        removed = False
        for idx in sorted(range(len(routes)), key=lambda i: len(routes[i])):
            others = [list(r) for i, r in enumerate(routes) if i != idx]
            ok = True
            for c in sorted(routes[idx], key=lambda c: inst["b"][c] - inst["a"][c]):
                best = None  # (extra distance, route index, position)
                for ri, r in enumerate(others):
                    if route_eval(r, inst)[2] + inst["q"][c] > inst["Q"] + EPS:
                        continue
                    for p in range(len(r) + 1):
                        x = r[p - 1] if p > 0 else 0
                        y = r[p] if p < len(r) else 0
                        extra = D[x][c] + D[c][y] - D[x][y]
                        if best is not None and extra >= best[0]:
                            continue
                        if route_eval(r[:p] + [c] + r[p:], inst)[0]:
                            best = (extra, ri, p)
                if best is None:
                    ok = False
                    break
                _, ri, p = best
                others[ri].insert(p, c)
            if ok:
                routes, removed = others, True
                break
        if not removed:
            break
    return routes


# --------------------------------------------------------------------------
# Local search ("education")
# --------------------------------------------------------------------------
def neighbor_lists(inst, k):
    """For each customer, its k nearest other customers (row by row, so the
    full table is never copied; argpartition finds the k smallest in O(n))."""
    D, n = inst["D"], inst["n"]
    lists = [[]]
    for u in range(1, n + 1):
        row = D[u]
        if isinstance(row, array):
            row = np.frombuffer(row, dtype=np.float32 if row.typecode == "f" else np.float64)
        row = np.asarray(row)[1:]  # customers only; index i means customer i + 1
        kk = min(k + 1, n)
        idx = np.argpartition(row, kk - 1)[:kk] if kk < n else np.arange(n)
        idx = idx[np.argsort(row[idx], kind="stable")]
        lists.append([int(i) + 1 for i in idx if int(i) + 1 != u][:k])
    return lists


def local_search(routes, inst, neighbors, rng, max_passes=50):
    """First-improvement local search. Each candidate move is first scored with
    an O(1) distance change; only improving moves are fully checked for
    capacity and time windows on the one or two routes they change."""
    D = inst["D"]
    routes = [list(r) for r in routes if r]

    def where():
        pos = {}
        for ri, r in enumerate(routes):
            for pi, c in enumerate(r):
                pos[c] = (ri, pi)
        return pos

    def pred_succ(r, p):
        return (r[p - 1] if p > 0 else 0), (r[p + 1] if p < len(r) - 1 else 0)

    def try_apply(changes, old_dist):
        """changes: {route index: new route}. Apply if all feasible and shorter.
        Then update the bookkeeping of the changed routes only (not the whole
        solution): this is what keeps it fast with thousands of customers.
        Emptied routes stay as [] until the end of the pass."""
        new_dist = 0.0
        for new_r in changes.values():
            if new_r:
                feasible, d, _ = route_eval(new_r, inst)
                if not feasible:
                    return False
                new_dist += d
        if new_dist < old_dist - 1e-6:
            for ri, new_r in changes.items():
                routes[ri] = new_r
                rdist[ri] = route_eval(new_r, inst)[1] if new_r else 0.0
                for pi, c in enumerate(new_r):
                    pos[c] = (ri, pi)
            return True
        return False

    customers = list(range(1, inst["n"] + 1))
    pos, rdist = {}, []
    for _ in range(max_passes):
        improved = False
        rng.shuffle(customers)
        routes = [r for r in routes if r]
        pos.clear()
        pos.update(where())
        rdist[:] = [route_eval(r, inst)[1] for r in routes]  # cached route lengths
        for u in customers:
            for v in neighbors[u]:
                ru_i, pu = pos[u]
                rv_i, pv = pos[v]
                ru, rv = routes[ru_i], routes[rv_i]
                u_pred, u_succ = pred_succ(ru, pu)
                v_pred, v_succ = pred_succ(rv, pv)
                same = ru_i == rv_i
                old = rdist[ru_i] + (0 if same else rdist[rv_i])
                applied = False

                # 1) Relocate u right after v
                if not (same and v == u_pred):
                    if same:
                        new = [c for c in ru if c != u]
                        k = new.index(v)
                        new.insert(k + 1, u)
                        applied = try_apply({ru_i: new}, old)
                    else:
                        delta = (D[v][u] + D[u][v_succ] - D[v][v_succ]
                                 - D[u_pred][u] - D[u][u_succ] + D[u_pred][u_succ])
                        if delta < -1e-6:
                            new_u = ru[:pu] + ru[pu + 1:]
                            new_v = rv[:pv + 1] + [u] + rv[pv + 1:]
                            applied = try_apply({ru_i: new_u, rv_i: new_v}, old)

                # 2) Relocate u right before v
                if not applied and not (same and v == u_succ):
                    if same:
                        new = [c for c in ru if c != u]
                        k = new.index(v)
                        new.insert(k, u)
                        applied = try_apply({ru_i: new}, old)
                    else:
                        delta = (D[v_pred][u] + D[u][v] - D[v_pred][v]
                                 - D[u_pred][u] - D[u][u_succ] + D[u_pred][u_succ])
                        if delta < -1e-6:
                            new_u = ru[:pu] + ru[pu + 1:]
                            new_v = rv[:pv] + [u] + rv[pv:]
                            applied = try_apply({ru_i: new_u, rv_i: new_v}, old)

                # 3) Swap u and v
                if not applied:
                    if same:
                        new = list(ru)
                        new[pu], new[pv] = new[pv], new[pu]
                        applied = try_apply({ru_i: new}, old)
                    else:
                        delta = (D[u_pred][v] + D[v][u_succ] - D[u_pred][u] - D[u][u_succ]
                                 + D[v_pred][u] + D[u][v_succ] - D[v_pred][v] - D[v][v_succ])
                        if delta < -1e-6:
                            new_u, new_v = list(ru), list(rv)
                            new_u[pu], new_v[pv] = v, u
                            applied = try_apply({ru_i: new_u, rv_i: new_v}, old)

                # 4) 2-opt* between two routes: exchange their tails after u and v
                if not applied and not same:
                    delta = D[u][v_succ] + D[v][u_succ] - D[u][u_succ] - D[v][v_succ]
                    if delta < -1e-6:
                        new_u = ru[:pu + 1] + rv[pv + 1:]
                        new_v = rv[:pv + 1] + ru[pu + 1:]
                        applied = try_apply({ru_i: new_u, rv_i: new_v}, old)

                # 5) 2-opt inside one route: reverse the segment between u and v
                if not applied and same:
                    i, j = sorted((pu, pv))
                    if j - i >= 2:
                        new = ru[:i + 1] + ru[i + 1:j + 1][::-1] + ru[j + 1:]
                        applied = try_apply({ru_i: new}, old)

                if applied:
                    improved = True
        if not improved:
            break
    return [r for r in routes if r]


# --------------------------------------------------------------------------
# Construction: randomized nearest neighbor with time windows (Solomon, 1987)
# --------------------------------------------------------------------------
def nearest_neighbor_tour(inst, rng, rcl=3, neighbors=None):
    """Build routes one at a time: from the last customer, go to a feasible
    unvisited customer with a low score (distance, waiting time, urgency).
    Picking at random among the rcl best gives a different tour each call,
    which keeps the initial population diverse. Returns a giant tour.

    Small instances look at every unvisited customer (O(n^2)). Big ones only
    look at the current customer's nearest neighbors (O(n x k))."""
    if neighbors is not None and inst["n"] > BIG:
        return _nearest_neighbor_tour_fast(inst, rng, rcl, neighbors)
    D, q, a, b, s, Q = inst["D"], inst["q"], inst["a"], inst["b"], inst["s"], inst["Q"]
    unvisited = set(range(1, inst["n"] + 1))
    tour = []
    while unvisited:
        load, t, prev = 0.0, a[0], 0
        while True:
            candidates = []
            for c in unvisited:
                if load + q[c] > Q + EPS:
                    continue
                arrival = t + s[prev] + D[prev][c]
                start = max(a[c], arrival)
                if start > b[c] + EPS or start + s[c] + D[c][0] > b[0] + EPS:
                    continue
                urgency = b[c] - arrival if b[c] < math.inf else 0.0  # no window: no urgency
                score = 0.4 * D[prev][c] + 0.4 * (start - t - s[prev]) + 0.2 * urgency
                candidates.append((score, c, start))
            if not candidates:
                if prev == 0:  # nobody fits even from the depot: serve one alone
                    c = unvisited.pop()
                    tour.append(c)
                break
            candidates.sort()
            _, c, start = rng.choice(candidates[:rcl])
            tour.append(c)
            unvisited.remove(c)
            load, t, prev = load + q[c], start, c
    return tour


def _nearest_neighbor_tour_fast(inst, rng, rcl, neighbors):
    """Same idea, for big instances. A route starts with an urgent customer
    (earliest closing window; ties: farthest from the depot), then keeps going
    to the best feasible unvisited customer among the current one's nearest
    neighbors. When none fits, the route closes and a new one starts.
    (Split later re-cuts the whole order optimally, so early closings are fine.)"""
    D, q, a, b, s, Q = inst["D"], inst["q"], inst["a"], inst["b"], inst["s"], inst["Q"]
    n = inst["n"]
    visited = [False] * (n + 1)
    start_order = sorted(range(1, n + 1), key=lambda c: (b[c], -D[0][c]))
    ptr, tour = 0, []
    while len(tour) < n:
        # first customer: random among the next rcl unvisited in start_order
        firsts, k = [], ptr
        while k < n and len(firsts) < rcl:
            if not visited[start_order[k]]:
                firsts.append(start_order[k])
            k += 1
        c = rng.choice(firsts)
        visited[c] = True
        tour.append(c)
        load, t, prev = q[c], max(a[c], a[0] + D[0][c]), c
        while True:
            candidates = []
            for c in neighbors[prev]:
                if visited[c] or load + q[c] > Q + EPS:
                    continue
                arrival = t + s[prev] + D[prev][c]
                start = max(a[c], arrival)
                if start > b[c] + EPS or start + s[c] + D[c][0] > b[0] + EPS:
                    continue
                urgency = b[c] - arrival if b[c] < math.inf else 0.0
                candidates.append((0.4 * D[prev][c] + 0.4 * (start - t - s[prev]) + 0.2 * urgency, c, start))
            if not candidates:
                break
            candidates.sort()
            _, c, start = rng.choice(candidates[:rcl])
            visited[c] = True
            tour.append(c)
            load, t, prev = load + q[c], start, c
        while ptr < n and visited[start_order[ptr]]:
            ptr += 1
    return tour


# --------------------------------------------------------------------------
# Genetic operators
# --------------------------------------------------------------------------
def order_crossover(p1, p2, rng):
    """OX: keep p1[i:j] in place, fill the other positions in p2's order."""
    n = len(p1)
    i, j = sorted(rng.sample(range(n + 1), 2))
    child = [None] * n
    child[i:j] = p1[i:j]
    kept = set(p1[i:j])
    fill = [c for c in p2[j:] + p2[:j] if c not in kept]
    for k, pos in enumerate(list(range(j, n)) + list(range(0, i))):
        child[pos] = fill[k]
    return child


def mutate(tour, rng):
    """Swap two customers, or reverse a segment of the order."""
    i, j = sorted(rng.sample(range(len(tour)), 2))
    if rng.random() < 0.5:
        tour[i], tour[j] = tour[j], tour[i]
    else:
        tour[i:j + 1] = tour[i:j + 1][::-1]
    return tour


def tournament(population, rng):
    """Binary tournament: draw two individuals, keep the better one."""
    x, y = rng.sample(population, 2)
    return x if x["cost"] <= y["cost"] else y


# --------------------------------------------------------------------------
# The genetic algorithm
# --------------------------------------------------------------------------
TRUCK_PENALTY = 10000.0  # added per truck above the limit: one extra truck is never worth it


def make_individual(tour, inst, neighbors, rng):
    """Decode a tour with Split, educate it, and store the improved order.
    Fitness = distance + TRUCK_PENALTY per truck above the limit k."""
    k = inst.get("vehicles")
    routes = split(tour, inst, k)
    if k is not None and len(routes) > k:
        routes = eliminate_routes(routes, inst, k)
    routes = local_search(routes, inst, neighbors, rng)
    if k is not None and len(routes) > k:
        routes = eliminate_routes(routes, inst, k)
    dist = total_distance(routes, inst)
    excess = max(0, len(routes) - k) if k is not None else 0
    cost = dist + TRUCK_PENALTY * excess
    return {
        "tour": [c for r in routes for c in r],  # Lamarckian: keep the improvement
        "routes": routes,
        "dist": dist,
        "excess": excess,
        "cost": cost,
        "key": round(cost, 4),  # used to spot clones
    }


def solve(inst, time_limit=60.0, seed=0, pop_size=None, max_pop=None,
          p_mutation=0.2, n_neighbors=20, max_no_improve=None, verbose=False, trace=None):
    """Run the GA and return (best routes, best distance, history).

    history = list of (seconds, best distance so far, trucks above the limit),
    for convergence plots. The truck limit is inst["vehicles"] when known.

    Intrinsic parameters (vary them in the experiments): pop_size, max_pop,
    p_mutation, n_neighbors. By default the population shrinks on big
    instances (25 up to 1,000 customers, 15 up to 3,000, then 8), because
    each individual costs more to build there.

    trace: pass an empty dict to get extra information about the run in it:
    the costs of the first and of the final population, and the number of
    generations (children) produced.
    """
    rng = random.Random(seed)
    start = time.process_time()
    n = inst["n"]
    if pop_size is None:
        pop_size = 25 if n <= 1000 else (15 if n <= BIG else 8)
    if max_pop is None:
        max_pop = 2 * pop_size
    neighbors = neighbor_lists(inst, n_neighbors)
    customers = list(range(1, n + 1))
    if max_no_improve is None:
        max_no_improve = 20 * n

    def new_tour(k):
        """Mostly randomized nearest-neighbor tours; on small instances one
        random tour in five for extra diversity (on big ones a random tour
        is far too slow to repair, so a more randomized nearest neighbor
        is used instead); the very first one is the greedy version."""
        if k == 0:
            return nearest_neighbor_tour(inst, rng, rcl=1, neighbors=neighbors)
        if k % 5 == 4:
            if n <= BIG:
                return rng.sample(customers, len(customers))
            return nearest_neighbor_tour(inst, rng, rcl=5, neighbors=neighbors)
        return nearest_neighbor_tour(inst, rng, rcl=3, neighbors=neighbors)

    # Initial population
    population = []
    while len(population) < pop_size and time.process_time() - start < time_limit:
        population.append(make_individual(new_tour(len(population)), inst, neighbors, rng))

    best = min(population, key=lambda ind: ind["cost"])
    history = [(time.process_time() - start, best["dist"], best["excess"])]
    if trace is not None:
        trace["first_population"] = sorted(ind["cost"] for ind in population)
    iteration, last_improve = 0, 0

    while time.process_time() - start < time_limit:
        iteration += 1
        # 1-2) selection and crossover
        p1, p2 = tournament(population, rng), tournament(population, rng)
        child_tour = order_crossover(p1["tour"], p2["tour"], rng)
        # 3) mutation
        if rng.random() < p_mutation:
            child_tour = mutate(child_tour, rng)
        # 4-5) decode with Split and educate with local search
        child = make_individual(child_tour, inst, neighbors, rng)
        # 6) replacement: add the child unless it is a clone
        if all(child["key"] != ind["key"] for ind in population):
            population.append(child)
        if len(population) > max_pop:
            population.sort(key=lambda ind: ind["cost"])
            population = population[:pop_size]

        if child["cost"] < best["cost"] - 1e-6:
            best = child
            last_improve = iteration
            history.append((time.process_time() - start, best["dist"], best["excess"]))
            if verbose:
                print(f"  it {iteration:6d}  t={history[-1][0]:7.1f}s  dist={best['dist']:.1f}  routes={len(best['routes'])}  over limit={best['excess']}")

        # Restart when stuck: keep the best quarter, refill with new tours
        if iteration - last_improve > max_no_improve:
            population.sort(key=lambda ind: ind["cost"])
            population = population[:max(2, pop_size // 4)]
            while len(population) < pop_size and time.process_time() - start < time_limit:
                population.append(make_individual(new_tour(len(population)), inst, neighbors, rng))
            last_improve = iteration

    history.append((time.process_time() - start, best["dist"], best["excess"]))
    if trace is not None:
        trace["final_population"] = sorted(ind["cost"] for ind in population)
        trace["generations"] = iteration
    return best["routes"], best["dist"], history


def lower_bound(inst):
    """A value that no solution can beat, used to judge quality when no
    best-known solution exists. Returns (bound, minimum number of trucks).

    Minimum trucks: total demand / capacity, rounded up.
    Bound 1 (arcs): every customer is left exactly once, so it pays at least
      its cheapest outgoing arc; the depot is left at least once per truck, so
      it pays at least its m cheapest outgoing arcs.
    Bound 2 (capacity): a truck that carries q_i for customer i must at least
      go to i and come back, and i uses the share q_i / Q of that truck, so the
      total is at least the sum of (d(0,i) + d(i,0)) * q_i / Q. This needs the
      triangle inequality, true for shortest-path and straight-line distances.
    Time windows only forbid solutions, so both bounds stay valid with them
    (but the bounds do not use the windows, so they are looser there)."""
    D, q, Q, n = inst["D"], inst["q"], inst["Q"], inst["n"]
    m = math.ceil(sum(q) / Q - EPS)
    arcs = 0.0
    for i in range(1, n + 1):
        row = np.array(D[i], dtype=float)
        row[i] = np.inf
        arcs += row.min()
    depot = np.sort(np.array(D[0], dtype=float)[1:])
    arcs += depot[:m].sum()
    capacity = sum((D[0][i] + D[i][0]) * q[i] / Q for i in range(1, n + 1))
    return max(arcs, capacity), m


def gap(cost, best_known):
    return 100.0 * (cost - best_known) / best_known


# --------------------------------------------------------------------------
# Command line
# --------------------------------------------------------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Memetic GA for CVRP / CVRPTW")
    parser.add_argument("instance")
    parser.add_argument("--time", type=float, default=60.0, help="CPU seconds")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--sol", help="best-known solution file, to compute the gap")
    parser.add_argument("--bks", type=float, help="best-known distance as a number, to compute the gap")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    inst = load_instance(args.instance)
    routes, cost, history = solve(inst, args.time, args.seed, verbose=args.verbose)
    ok, checked_cost, msg = check_solution(routes, inst)
    print(f"{inst['name']}: distance {cost:.2f}, trucks {len(routes)}/{inst.get('vehicles')}, feasible {ok} ({msg})")
    bks = args.bks if args.bks else (vrplib.read_solution(args.sol)["cost"] if args.sol else None)
    if bks:
        print(f"best known {bks:.1f}, gap {gap(cost, bks):.2f}%")
