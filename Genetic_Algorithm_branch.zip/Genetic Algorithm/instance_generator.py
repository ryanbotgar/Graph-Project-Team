"""
Shared instance generator for the CVRPTW project.

It turns a ROAD GRAPH into a delivery instance:
  1. Road graph      : synthetic (NetworkX) or a real city (OpenStreetMap).
  2. Places          : one depot + n customers, picked among the graph's nodes.
  3. Travel times    : shortest paths along the roads between every pair of
                       places (not straight lines). Real cities have one-way
                       streets, so time(i -> j) can differ from time(j -> i).
  4. Orders          : a demand per customer, a truck capacity, time windows,
                       a service time.
  5. Saved file      : one .npz file that all three algorithms load with
                       load_generated(path).

Extrinsic parameters you can vary (the "problem conditions"):
  --customers   number of customers (100 ... 10000)
  --layout      random | clustered     where the customers are
  --tw          tight | wide | none    width of the time windows
  --route-size  customers per truck that the capacity allows (small = tight capacity)
  graph type    synthetic | osm

Examples:
  python instance_generator.py synthetic --customers 100 --layout clustered --tw tight --seed 1
  python instance_generator.py osm --place "Nanterre, France" --customers 500 --tw wide --seed 1
  python instance_generator.py grid --out instances     # the whole experiment grid (synthetic)
"""

import argparse
import json
import math
import os

import networkx as nx
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra


# --------------------------------------------------------------------------
# 1. Road graphs
# --------------------------------------------------------------------------
def synthetic_graph(n_nodes, seed=0, size=1000.0, speed=1.0):
    """A road-like graph made with NetworkX: random intersections in a
    size x size square, joined when they are close (random geometric graph).
    Only the largest connected part is kept, so every node can reach every
    other one. Edge weight 'time' = road length / speed."""
    radius = math.sqrt(2.0 * math.log(n_nodes) / (math.pi * n_nodes))  # just above the connectivity threshold
    g = nx.random_geometric_graph(n_nodes, radius, seed=seed)
    g = g.subgraph(max(nx.connected_components(g), key=len)).copy()
    for v, data in g.nodes(data=True):
        x, y = data["pos"]
        data["x"], data["y"] = x * size, y * size
    for u, v, data in g.edges(data=True):
        length = math.hypot(g.nodes[u]["x"] - g.nodes[v]["x"], g.nodes[u]["y"] - g.nodes[v]["y"])
        data["length"] = length
        data["time"] = length / speed
    return g


# Speeds (km/h) used only where OpenStreetMap has no speed limit for a road;
# typical French limits. Roads of other types fall back to 30 km/h.
DEFAULT_SPEEDS_KMH = {
    "motorway": 110, "motorway_link": 70, "trunk": 90, "trunk_link": 50,
    "primary": 50, "primary_link": 50, "secondary": 50, "secondary_link": 50,
    "tertiary": 50, "tertiary_link": 50, "unclassified": 30, "residential": 30,
    "living_street": 20, "service": 20,
}


def osm_graph(place=None, point=None, dist=3000):
    """A real street network from OpenStreetMap (needs internet).
    place: a name like "Nanterre, France"; or point=(lat, lon) with a radius
    dist in metres. Edge weight 'time' = travel time in seconds, from the
    speed limits (OSMnx fills missing ones by road type). Only the largest
    strongly connected part is kept: from every node you can drive to every
    other node, respecting one-way streets."""
    import osmnx as ox
    if place:
        g = ox.graph_from_place(place, network_type="drive")
    else:
        g = ox.graph_from_point(point, dist=dist, network_type="drive")
    # OSMnx 2.x moved these functions; support both versions
    routing = getattr(ox, "routing", ox)
    g = routing.add_edge_speeds(g, hwy_speeds=DEFAULT_SPEEDS_KMH, fallback=30)
    g = routing.add_edge_travel_times(g)
    if hasattr(ox, "truncate") and hasattr(ox.truncate, "largest_component"):
        g = ox.truncate.largest_component(g, strongly=True)
    else:
        g = ox.utils_graph.get_largest_component(g, strongly=True)
    for u, v, k, data in g.edges(keys=True, data=True):
        data["time"] = float(data["travel_time"])
    return g


# --------------------------------------------------------------------------
# 2-3. Places and road travel times
# --------------------------------------------------------------------------
def _sparse_matrix(g, nodes, weight):
    """Graph -> sparse matrix of edge weights (keeps the fastest of parallel roads)."""
    index = {v: i for i, v in enumerate(nodes)}
    best = {}
    edges = g.edges(data=weight)
    for u, v, w in edges:
        for a, b in ([(u, v)] if g.is_directed() else [(u, v), (v, u)]):
            key = (index[a], index[b])
            if key not in best or w < best[key]:
                best[key] = w
    rows, cols = zip(*best) if best else ((), ())
    return csr_matrix((list(best.values()), (rows, cols)), shape=(len(nodes), len(nodes)))


def travel_time_matrix(g, places, weight="time", batch=500):
    """Shortest travel time between every pair of chosen places, along the
    roads. Computed with SciPy's Dijkstra, in batches so the memory stays
    small even with 10,000 places. Returns a float32 matrix."""
    nodes = list(g.nodes)
    index = {v: i for i, v in enumerate(nodes)}
    graph = _sparse_matrix(g, nodes, weight)
    idx = np.array([index[p] for p in places])
    out = np.empty((len(places), len(places)), dtype=np.float32)
    for start in range(0, len(idx), batch):
        rows = dijkstra(graph, directed=True, indices=idx[start:start + batch])
        out[start:start + batch] = rows[:, idx]
    if not np.isfinite(out).all():
        raise ValueError("some places cannot reach each other: graph not connected")
    return out


def pick_places(g, n_customers, layout, rng, n_clusters=None):
    """Depot = the node closest to the centre of the map.
    Customers: 'random' = spread uniformly over the nodes;
               'clustered' = grouped around a few random centres.
    If the graph has fewer nodes than customers, some customers share a
    node (like several shops in one street); a warning is printed."""
    nodes = list(g.nodes)
    xy = np.array([[g.nodes[v]["x"], g.nodes[v]["y"]] for v in nodes])
    centre = xy.mean(axis=0)
    depot_i = int(np.argmin(((xy - centre) ** 2).sum(axis=1)))
    others = np.array([i for i in range(len(nodes)) if i != depot_i])
    replace = n_customers > len(others)
    if replace:
        print(f"warning: {n_customers} customers but only {len(others)} road nodes; some share a node")

    if layout == "random":
        chosen = rng.choice(others, size=n_customers, replace=replace)
    elif layout == "clustered":
        k = n_clusters or max(3, int(round(math.sqrt(n_customers) / 2)))
        centres = xy[rng.choice(others, size=k, replace=False)]
        spread = 0.05 * (xy.max(axis=0) - xy.min(axis=0)).max()
        weights = np.zeros(len(others))
        for c in centres:  # each node gets a weight that is high near a centre
            weights += np.exp(-((xy[others] - c) ** 2).sum(axis=1) / (2 * spread ** 2))
        weights /= weights.sum()
        chosen = rng.choice(others, size=n_customers, replace=replace, p=weights)
    else:
        raise ValueError("layout must be 'random' or 'clustered'")
    return nodes[depot_i], [nodes[i] for i in chosen], xy[[depot_i, *chosen]]


# --------------------------------------------------------------------------
# 4. Orders: demand, capacity, time windows, service time
# --------------------------------------------------------------------------
def make_orders(T, rng, route_size=10, tw="wide", service=None, max_demand=10):
    """T = travel-time matrix with the depot at index 0.

    demand   : random integer 1..max_demand per customer
    capacity : Q = route_size x average demand (route_size = how many customers
               a full truck can serve: small = tight capacity)
    service  : unloading time per customer (default: 10% of the median trip from the depot)
    horizon  : the depot opens at 0 and closes at H, long enough for a truck to
               serve route_size customers and come back
    windows  : for each customer, a window [a, b] of width w*H placed at random
               between the earliest possible arrival and the latest time
               that still lets the truck get home. tight w = 0.05, wide w = 0.25,
               none = the whole day. Every customer can always be served alone.
    """
    n = T.shape[0] - 1
    demand = np.zeros(n + 1)
    demand[1:] = rng.integers(1, max_demand + 1, size=n)
    Q = float(round(route_size * demand[1:].mean()))
    Q = max(Q, demand.max())

    from_depot, to_depot = T[0, 1:].astype(float), T[1:, 0].astype(float)
    if service is None:
        service = 0.1 * float(np.median(from_depot))
    s = np.full(n + 1, service)
    s[0] = 0.0

    # typical hop between neighbouring customers (estimated on a sample)
    sample = rng.choice(np.arange(1, n + 1), size=min(n, 500), replace=False)
    sub = T[np.ix_(sample, np.arange(1, n + 1))].astype(float)
    sub[sub == 0] = np.inf
    hop = float(np.median(sub.min(axis=1)))
    if not np.isfinite(hop):
        hop = float(np.median(from_depot))
    H = float(from_depot.max() + to_depot.max() + 1.5 * route_size * (service + 2 * hop))

    a, b = np.zeros(n + 1), np.zeros(n + 1)
    a[0], b[0] = 0.0, H
    earliest = from_depot  # arrive straight from the depot
    latest = H - service - to_depot  # last start that still lets the truck get home
    width = {"tight": 0.05, "wide": 0.25, "none": None}[tw]
    for c in range(1, n + 1):
        lo, hi = earliest[c - 1], latest[c - 1]
        if width is None:
            a[c], b[c] = 0.0, hi
            continue
        w = width * H
        centre = rng.uniform(lo, hi)
        a[c] = max(0.0, centre - w / 2)
        b[c] = min(hi, centre + w / 2)
        b[c] = max(b[c], lo)  # always reachable when served alone
        a[c] = min(a[c], b[c])
    return demand, Q, a, b, s, H


# --------------------------------------------------------------------------
# 5. Build, save and load
# --------------------------------------------------------------------------
def build_instance(g, n_customers, seed=0, layout="random", tw="wide", route_size=10,
                   service=None, vehicles=None, name=None, graph_type="synthetic"):
    rng = np.random.default_rng(seed)
    depot, customers, coords = pick_places(g, n_customers, layout, rng)
    T = travel_time_matrix(g, [depot, *customers])
    demand, Q, a, b, s, H = make_orders(T, rng, route_size, tw, service)
    meta = dict(name=name or f"{graph_type}_{layout}_{tw}_n{n_customers}_s{seed}",
                graph_type=graph_type, layout=layout, tw=tw, customers=n_customers,
                route_size=route_size, seed=seed, graph_nodes=g.number_of_nodes(),
                graph_edges=g.number_of_edges(), horizon=H,
                symmetric=bool(np.allclose(T, T.T)), time_unit="seconds" if graph_type == "osm" else "units")
    return dict(T=T, coords=coords.astype(np.float32), demand=demand, Q=Q, a=a, b=b, s=s,
                vehicles=vehicles if vehicles is not None else n_customers, meta=meta)


def save_instance(inst, path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    np.savez_compressed(path, T=inst["T"], coords=inst["coords"], demand=inst["demand"],
                        Q=inst["Q"], a=inst["a"], b=inst["b"], s=inst["s"],
                        vehicles=inst["vehicles"], meta=json.dumps(inst["meta"]))
    return path


def load_generated(path):
    """Load a generated instance. Same keys for every algorithm:
      T        (n+1) x (n+1) travel times, depot = 0, T[i][j] = time from i to j
      demand   demand[0] = 0 for the depot
      Q        truck capacity
      a, b     time window of each node (b[0] = depot closing time)
      s        service time (s[0] = 0)
      vehicles truck limit (default = number of customers, i.e. no real limit)
      coords   x, y of each place (for plots)
      meta     dict with how the instance was made
    """
    z = np.load(path, allow_pickle=False)
    return dict(T=z["T"], coords=z["coords"], demand=z["demand"], Q=float(z["Q"]),
                a=z["a"], b=z["b"], s=z["s"], vehicles=int(z["vehicles"]),
                meta=json.loads(str(z["meta"])))


def check_instance(inst):
    """Every customer must be servable alone: reach it, serve it inside its
    window, and get back before the depot closes; demand must fit in a truck."""
    T, a, b, s, q, Q = inst["T"], inst["a"], inst["b"], inst["s"], inst["demand"], inst["Q"]
    problems = []
    for c in range(1, len(q)):
        start = max(a[c], T[0, c])
        if start > b[c] + 1e-6 or start + s[c] + T[c, 0] > b[0] + 1e-6 or q[c] > Q:
            problems.append(c)
    return problems


# --------------------------------------------------------------------------
# Command line
# --------------------------------------------------------------------------
def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("mode", choices=["synthetic", "osm", "grid"])
    p.add_argument("--customers", type=int, default=100)
    p.add_argument("--layout", default="random", choices=["random", "clustered"])
    p.add_argument("--tw", default="wide", choices=["tight", "wide", "none"])
    p.add_argument("--route-size", type=int, default=10)
    p.add_argument("--seed", type=int, default=1)
    p.add_argument("--place", help='OpenStreetMap place, e.g. "Nanterre, France"')
    p.add_argument("--point", help="lat,lon instead of a place name")
    p.add_argument("--dist", type=float, default=3000, help="radius in metres around --point")
    p.add_argument("--sizes", default="100,500,1000,5000,10000", help="grid mode: customer counts")
    p.add_argument("--out", default="instances")
    args = p.parse_args()

    if args.mode == "grid":
        # The extrinsic grid on synthetic maps: sizes x layouts x windows
        for n in [int(x) for x in args.sizes.split(",")]:
            g = synthetic_graph(max(2 * (n + 1), 500), seed=args.seed)
            for layout in ["random", "clustered"]:
                for tw in ["tight", "wide"]:
                    inst = build_instance(g, n, args.seed, layout, tw, args.route_size)
                    path = save_instance(inst, os.path.join(args.out, inst["meta"]["name"] + ".npz"))
                    print("saved", path, "| problems:", len(check_instance(inst)))
        return

    if args.mode == "synthetic":
        g = synthetic_graph(max(2 * (args.customers + 1), 500), seed=args.seed)
    else:
        point = tuple(float(v) for v in args.point.split(",")) if args.point else None
        g = osm_graph(place=args.place, point=point, dist=args.dist)
    inst = build_instance(g, args.customers, args.seed, args.layout, args.tw, args.route_size,
                          graph_type=args.mode)
    if args.mode == "osm":
        tag = (args.place or args.point).split(",")[0].replace(" ", "")
        inst["meta"]["name"] = f"osm-{tag}_{args.layout}_{args.tw}_n{args.customers}_s{args.seed}"
    path = save_instance(inst, os.path.join(args.out, inst["meta"]["name"] + ".npz"))
    print("saved", path, "| graph", inst["meta"]["graph_nodes"], "nodes | problems:", len(check_instance(inst)))


if __name__ == "__main__":
    main()
