"""
Shared instance loader for the team (same code the genetic algorithm uses).

Everyone loads instances with this file, so all algorithms see exactly the
same numbers (same distances, same rounding, same truck limit).

Reads 4 kinds of files, detected automatically:
  - VRPLIB .vrp files      (AGS Belgium instances, X set, ...)       -> CVRP
  - Solomon .txt files     (from the NEO website)                    -> CVRPTW
  - Cordeau files          (the C-vrptw.zip files, numbers only)     -> CVRPTW
  - .npz files             (made by instance_generator.py: NetworkX / OpenStreetMap)

Returns a plain dict:
  name      instance name
  n         number of customers (customers are 1..n, the depot is 0)
  Q         truck capacity
  vehicles  max number of trucks (None = no limit given in the file)
  D         D[i][j] = distance (or travel time) from i to j
  q         q[i] = demand of node i
  a, b      a[i], b[i] = time window of node i (b = inf for plain CVRP)
  s         s[i] = service time at node i
  has_tw    True if the instance has time windows

Also gives check_solution(routes, inst): the same independent checker for
everyone. A solution is a list of routes, each a list of customers without
the depot, e.g. [[3, 1, 7], [2, 5], [4, 6]].

Usage in your code:
    from load_instances import load_instance, check_solution
    inst = load_instance("Ghent1.vrp")
    ok, total, msg = check_solution(my_routes, inst)

Quick look at a file from the terminal:
    python load_instances.py Ghent1.vrp
"""

import math
from array import array

import numpy as np
import vrplib

EPS = 1e-9
BIG = 3000  # above this many customers: 4-byte numbers to save memory

# --------------------------------------------------------------------------
# Compact distance storage
# --------------------------------------------------------------------------
# The distance table is a list of rows; each row is a Python array of numbers.
# Small instances use 8-byte numbers ('d', exact). Big ones use 4-byte numbers
# ('f'): a 10,000-customer table then takes 400 MB instead of about 3 GB as a
# list of lists, and D[i][j] stays a fast lookup.
def _round(d, rounding):
    if rounding == "dimacs":
        return np.floor(d * 10.0 + 1e-6) / 10.0
    if rounding == "round":
        return np.floor(d + 0.5)
    return d


def _typecode(n_nodes):
    return "f" if n_nodes - 1 > BIG else "d"


def _rows_from_matrix(M, rounding="none"):
    M = np.asarray(M)
    code = _typecode(M.shape[0])
    dtype = np.float32 if code == "f" else np.float64
    rows = []
    for i in range(M.shape[0]):
        r = array(code)
        r.frombytes(np.ascontiguousarray(_round(M[i].astype(float), rounding), dtype=dtype).tobytes())
        rows.append(r)
    return rows


def _rows_from_coords(X, Y, rounding):
    """Euclidean distances computed one row at a time (never the full table at once)."""
    X, Y = np.asarray(X, dtype=float), np.asarray(Y, dtype=float)
    code = _typecode(len(X))
    dtype = np.float32 if code == "f" else np.float64
    rows = []
    for i in range(len(X)):
        r = array(code)
        r.frombytes(_round(np.hypot(X - X[i], Y - Y[i]), rounding).astype(dtype).tobytes())
        rows.append(r)
    return rows


# --------------------------------------------------------------------------
# Instance loading
# --------------------------------------------------------------------------
def load_instance(path, rounding="auto"):
    """Read an instance and return a plain dict the solver uses.

    Accepts both file formats: Solomon .txt files (as downloaded from the
    NEO website) and VRPLIB .vrp files. The format is detected from the file.

    rounding: "dimacs" truncates distances to one decimal (VRPTW benchmark
    convention), "round" rounds to the nearest integer (CVRP benchmark
    convention), "none" keeps exact distances, "auto" picks by problem type.
    """
    if str(path).endswith(".npz"):  # made by instance_generator.py
        return _read_generated(path)
    with open(path) as f:
        head = f.read(2000).upper()
    if not any(ch.isalpha() for ch in head):  # only numbers: Cordeau format
        return _read_cordeau(path, "none" if rounding == "auto" else rounding)
    fmt = "solomon" if ("CUST NO" in head or "VEHICLE" in head and "NODE_COORD" not in head) else "vrplib"
    # compute_edge_weights=False: vrplib would build the full table in 8-byte
    # numbers (800 MB at 10,000 customers); we build compact rows ourselves.
    raw = vrplib.read_instance(path, instance_format=fmt, compute_edge_weights=False)
    n_nodes = len(raw["demand"])  # depot + customers (works for both formats)
    has_tw = "time_window" in raw
    if rounding == "auto":
        rounding = "dimacs" if has_tw else "round"
    if "edge_weight" in raw:  # explicit table in the file: use it as given
        D = _rows_from_matrix(raw["edge_weight"])
    else:
        xy = np.asarray(raw["node_coord"], dtype=float)
        D = _rows_from_coords(xy[:, 0], xy[:, 1], rounding)

    demand = np.asarray(raw["demand"], dtype=float)
    if has_tw:
        tw = np.asarray(raw["time_window"], dtype=float)
        ready, due = tw[:, 0].copy(), tw[:, 1].copy()
    else:  # plain CVRP: windows that never bind
        ready, due = np.zeros(n_nodes), np.full(n_nodes, np.inf)

    service = np.asarray(raw.get("service_time", 0), dtype=float).ravel()
    if service.size == 1:  # one value for every customer
        service = np.full(n_nodes, service[0])
    service[0] = 0.0  # no service at the depot

    return {
        "name": raw.get("name", str(path)),
        "n": n_nodes - 1,  # number of customers
        "Q": float(raw["capacity"]),
        "vehicles": int(raw["vehicles"]) if "vehicles" in raw else None,
        "D": D,
        "q": demand.tolist(),
        "a": ready.tolist(),
        "b": due.tolist(),
        "s": service.tolist(),
        "has_tw": has_tw,
    }


def _read_generated(path):
    """Instances from instance_generator.py: road travel times (possibly
    asymmetric because of one-way streets), demands, windows, service times.
    The cost to minimize is the total travel time."""
    import json
    import os
    z = np.load(path, allow_pickle=False)
    T = z["T"]
    meta = json.loads(str(z["meta"]))
    return {
        "name": meta.get("name", os.path.basename(path)), "n": T.shape[0] - 1,
        "Q": float(z["Q"]), "vehicles": int(z["vehicles"]), "D": _rows_from_matrix(T),
        "q": z["demand"].astype(float).tolist(), "a": z["a"].astype(float).tolist(),
        "b": z["b"].astype(float).tolist(), "s": z["s"].astype(float).tolist(),
        "has_tw": True, "meta": meta,
    }


def _read_cordeau(path, rounding):
    """Cordeau's VRPTW format (the files in C-vrptw.zip).

    Line 1: type, m (number of trucks), n (customers), t (depots)
    Line 2: D (max route duration, 0 = none), Q (truck capacity)
    Then one line per node: i, x, y, service time, demand, f, a,
    a visit-combination numbers, ready time, due time.
    Read token by token, so line breaks do not matter.
    """
    import os
    tok = open(path).read().split()
    _, m, n, t = (int(float(v)) for v in tok[:4])
    pos = 4
    _, Q = float(tok[pos]), float(tok[pos + 1])
    pos += 2 * t
    xs, ys, s, q, a, b = [], [], [], [], [], []
    for _ in range(n + 1):
        x, y, d, dem, f, ncomb = tok[pos + 1:pos + 7]
        pos += 7 + int(float(ncomb))
        e, l = tok[pos], tok[pos + 1]
        pos += 2
        xs.append(float(x)); ys.append(float(y)); s.append(float(d))
        q.append(float(dem)); a.append(float(e)); b.append(float(l))
    s[0] = 0.0
    return {
        "name": os.path.basename(path), "n": n, "Q": Q, "vehicles": m,
        "D": _rows_from_coords(xs, ys, rounding), "q": q, "a": a, "b": b, "s": s, "has_tw": True,
    }


# --------------------------------------------------------------------------
# Route evaluation and an independent checker
# --------------------------------------------------------------------------
def route_eval(route, inst):
    """Return (feasible, distance, load) of one route depot -> route -> depot.

    Service at customer c starts at max(arrival, a[c]): the truck may wait.
    The route is infeasible if any service starts after b[c], if the truck
    gets back to the depot after b[0], or if the load exceeds Q.
    """
    D, q, a, b, s = inst["D"], inst["q"], inst["a"], inst["b"], inst["s"]
    load, dist, t, prev = 0.0, 0.0, a[0], 0
    for c in route:
        load += q[c]
        dist += D[prev][c]
        t = max(a[c], t + s[prev] + D[prev][c])
        if t > b[c] + EPS:
            return False, dist, load
        prev = c
    dist += D[prev][0]
    back = t + s[prev] + D[prev][0]
    feasible = load <= inst["Q"] + EPS and back <= b[0] + EPS
    return feasible, dist, load


def check_solution(routes, inst):
    """Independent check: every customer exactly once, every route feasible,
    and no more trucks than allowed. Returns (ok, total distance, message)."""
    seen = [c for r in routes for c in r]
    if sorted(seen) != list(range(1, inst["n"] + 1)):
        return False, math.inf, "customers missing or visited twice"
    k = inst.get("vehicles")
    if k is not None and len(routes) > k:
        return False, total_distance(routes, inst), f"{len(routes)} trucks used, only {k} allowed"
    total = 0.0
    for k, r in enumerate(routes):
        feasible, dist, load = route_eval(r, inst)
        if not feasible:
            return False, math.inf, f"route {k} breaks capacity or a time window"
        total += dist
    return True, total, "ok"


def total_distance(routes, inst):
    return sum(route_eval(r, inst)[1] for r in routes)


if __name__ == "__main__":
    import sys
    import time
    for path in sys.argv[1:]:
        t0 = time.time()
        inst = load_instance(path)
        tw = "with time windows" if inst["has_tw"] else "no time windows (CVRP)"
        print(f"{inst['name']}: {inst['n']} customers, capacity {inst['Q']:g}, "
              f"trucks allowed {inst['vehicles']}, {tw}, "
              f"total demand {sum(inst['q']):g}, loaded in {time.time() - t0:.1f}s")
