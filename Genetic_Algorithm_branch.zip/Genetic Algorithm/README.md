# Genetic algorithm (memetic) for the CVRPTW

| File | What it is |
|---|---|
| `GA_section.ipynb` | The notebook section: algorithm explained cell by cell, experiments, charts, interpretation, references |
| `ga_cvrptw.py` | The solver as a single Python file |
| `load_instances.py` | Shared instance loader (VRPLIB, Solomon, Cordeau, generated `.npz`) and solution checker |
| `instance_generator.py` | Generator of NetworkX and OpenStreetMap instances |
| `experiments.py` | Script that ran the experiment campaign |
| `results_ga.csv`, `results_time.csv`, `results_cordeau_seed1_with_gap.csv`, `lower_bounds.csv` | One row per run; read by the notebook |
| `instances/` | The 12 generated instances with 100, 500 and 1,000 customers |

The 5,000 and 10,000-customer instances are too large for GitHub (85 to 340 MB each). Regenerate them with
`python instance_generator.py grid --sizes 5000,10000 --out instances`, or get them from the team's shared drive.

To run the notebook in Colab, upload `GA_section.ipynb`, `instance_generator.py` and the four CSV files to the same session, then Runtime > Run all.

Scope: the implementation solves the model with a single time slot (fixed travel times), with capacity and time windows, and minimises total travel time.
